package com.retry.flixy.viewmodel;

import androidx.lifecycle.ViewModel;

import io.reactivex.disposables.CompositeDisposable;

public class HomeViewModel extends ViewModel {
    CompositeDisposable disposable = new CompositeDisposable();


}


